<?php


?>
<!--- 
	tes frame uploader 
	input dgn id = outtext sebagai penampung nama file yg baru di upload
-->
<input type='text' id= 'outtext' value=''> <br>
<iframe width=400 height=300 scrolling=no id='uploadtarget'  name='uploader' src ='uploader.php?nmFile=runall.bmp'>