<?

switch ($bulan)
	{
		case "01":
			$bulan2 = "Januari";	break;
		case "02":
			$bulan2 = "Februari";  break;
		case "03":
			$bulan2 = "Maret";	break;
		case "04":
			$bulan2 = "April"; break;
		case "05":
			$bulan2 = "Mei"; break;
		case "06":
			$bulan2 = "Juni"; break;
		case "07":
			$bulan2 = "Juli"; break;
		case "08":
			$bulan2 = "Agustus"; break;
		case "09":
			$bulan2 = "September"; break;
		case "10":
			$bulan2 = "Oktober"; break;	
		case "11":
			$bulan2 = "November"; break;
		case "12":
			$bulan2 = "Desember"; break;
	}
?>