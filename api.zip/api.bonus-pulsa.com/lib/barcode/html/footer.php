<?php
if(!defined('IN_CB'))die('You are not allowed to access to this page.');
?>
</body>
</html>