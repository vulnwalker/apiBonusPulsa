<?php
//////////////////////////////////////////////////////////////////////
// index.php
//--------------------------------------------------------------------
//
// Holding Constant
//
//--------------------------------------------------------------------
// Revision History
// V1.02	8  mar	2005	Jean-Sebastien Goupil	Spreading all Classes in single file
// V1.00	17 jun	2004	Jean-Sebastien Goupil
//--------------------------------------------------------------------
// Copyright (C) Jean-Sebastien Goupil
// http://other.lookstrike.com/barcode/
//--------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////
if(!defined('IN_CB'))die('You are not allowed to access to this page.');

//////////////////////////////////////////////////////////////////////
// Constants
//////////////////////////////////////////////////////////////////////
define('IMG_FORMAT_PNG',	1);
define('IMG_FORMAT_JPEG',	2);
define('IMG_FORMAT_WBMP',	4);
define('IMG_FORMAT_GIF',	8);
?>