<?php
$Main->Isi="
<table border=0 cellspacing=4 width=50%>
	<tr>
	<td valign=top>
		<table border=0 cellspacing=0 width=100% class=\"adminform\">
			<tr><th colspan=2>INPUT DATA</th></tr>
			<tr><td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=01#ISIAN",$Image="sections.png",$Isi="Kartu Pengawasan dan Pengendalian")."
		<!-- ".PanelIcon($Link="?Pg=$Pg&SPg=03#ISIAN",$Image="sections.png",$Isi="Rencana Kebutuhan Pemeliharaan Barang")."
		</td>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=02#ISIAN",$Image="sections.png",$Isi="Daftar Kebutuhan Barang")."
		".PanelIcon($Link="?Pg=$Pg&SPg=04#ISIAN",$Image="sections.png",$Isi="Daftar Kebutuhan Pemeliharaan Barang")."
		</td></tr>
		</table>
	</td>
	<td>&nbsp</td>
	<td>&nbsp</td>
	<td>&nbsp</td>
	<td valign=top>
		<table border=0 cellspacing=0 width=100% class=\"adminform\">
		<tr><th colspan=2>DAFTAR</th>
		</tr>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=05#ISIAN",$Image="module.png",$Isi="Rencana Kebutuhan Barang")."
		".PanelIcon($Link="?Pg=$Pg&SPg=06#ISIAN",$Image="module.png",$Isi="Rencana Kebutuhan Pemeliharaan Barang")."
		</td>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=07#ISIAN",$Image="module.png",$Isi="Daftar Kebutuhan Barang")."
		".PanelIcon($Link="?Pg=$Pg&SPg=08#ISIAN",$Image="module.png",$Isi="Daftar Kebutuhan Pemeliharaan Barang")." -->
		</td>
		</tr>
		</table>
	</td>
	</tr>
</table>

		";
?>