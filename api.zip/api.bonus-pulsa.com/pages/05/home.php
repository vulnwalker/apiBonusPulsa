<?php
$Main->Isi="
<table border=0 cellspacing=4 width=50%>
	<tr>
	<td valign=top>
		<table border=0 cellspacing=0 width=100% class=\"adminform\">
			<tr><th colspan=2>INPUT DATA</th></tr>
			<tr><td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=01",$Image="sections.png",$Isi="Data Inventaris")."
		".PanelIcon($Link="?Pg=$Pg&SPg=02",$Image="sections.png",$Isi="Data KIR")."
		</td></tr>
		</table>
	</td>
	<td>&nbsp</td>
	<td>&nbsp</td>
	<td>&nbsp</td>
	<td valign=top>
		<table border=0 cellspacing=0 width=100% class=\"adminform\">
		<tr><th colspan=4>D A F T A R</th>
		</tr>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=03",$Image="module.png",$Isi="Buku Inventaris")."
		".PanelIcon($Link="?Pg=$Pg&SPg=07",$Image="module.png",$Isi="KIB D Jalan, Irigasi, dan Jaringan")."
		".PanelIcon($Link="?Pg=$Pg&SPg=11",$Image="module.png",$Isi="Rekap Buku Inventaris")."
		</td>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=04",$Image="module.png",$Isi="KIB A Tanah")."
		".PanelIcon($Link="?Pg=$Pg&SPg=08",$Image="module.png",$Isi="KIB E Aset Tetap Lainnya")."
		</td>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=05",$Image="module.png",$Isi="KIB B Peralatan dan Mesin")."
		".PanelIcon($Link="?Pg=$Pg&SPg=09",$Image="module.png",$Isi="KIB F Konstruksi Dalam Pengerjaan")."
		</td>
		<td valign=top>
		".PanelIcon($Link="?Pg=$Pg&SPg=06",$Image="module.png",$Isi="KIB C Gedung dan Bangunan")."
		".PanelIcon($Link="?Pg=$Pg&SPg=10",$Image="module.png",$Isi="Data Inventaris Ruangan (KIR)")."
		</td>
		</tr>
		</table>
	</td>
	</tr>
</table>

";
?>