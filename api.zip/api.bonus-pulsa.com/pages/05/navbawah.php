<?php
$Main->NavBawah = "
<!-- <table width=\"100%\" class=\"menubar\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"menudottedline\" width=\"100%\" height=\"30\"><center>
	<A href=\"?Pg=\" target=\"_blank\">Buku Inventaris</a> |
	<A href=\"?Pg=\" target=\"_blank\">Rekapitulasi Buku Inventaris</a> |
	<A href=\"?Pg=\" target=\"_blank\">Laporan Mutasi Barang per Semester</a> |
	<A href=\"?Pg=\" target=\"_blank\">Laporan Mutasi Barang per Tahun</a> |

	</td>

</tr>
</table> -->
";

?>