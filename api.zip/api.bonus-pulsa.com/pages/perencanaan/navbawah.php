<?php
$Main->NavBawah = "
<table width=\"100%\" class=\"menubar\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"menudottedline\" width=\"100%\" height=\"30\"><center>
	<A href=\"?Pg=\" target=\"_blank\">NAV1</a> |
	<A href=\"?Pg=\" target=\"_blank\">NAV2</a> |
	</td>

</tr>
</table>
";

?>