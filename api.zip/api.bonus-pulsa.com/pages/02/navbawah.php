<?php
$Main->NavBawah = "
<!-- <table width=\"100%\" class=\"menubar\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr>
	<td class=\"menudottedline\" width=\"100%\" height=\"30\"><center>
	<A href=\"?Pg=\" target=\"_blank\">Daftar Kebutuhan Barang</a> |
	<A href=\"?Pg=\" target=\"_blank\">Daftar Kebutuhan Pemeliharaan Barang</a> |
	</td>

</tr>
</table> -->
";

?>